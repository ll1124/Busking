//
//  Tab1ListCellTableViewCell.swift
//  busking app
//
//  Created by 방문사용자 on 2018. 8. 6..
//  Copyright © 2018년 kr.ac.korea. All rights reserved.
//

import UIKit

class Tab1ListCellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
